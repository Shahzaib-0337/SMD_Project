import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'package:smart_travel_companion/app.dart';

void main() {
  testWidgets('App boots and shows Explore Places', (WidgetTester tester) async {
    await tester.pumpWidget(const ProviderScope(child: SmartTravelApp()));
    await tester.pump();

    expect(find.text('Explore Places'), findsOneWidget);
  });
}
