class WeatherSnapshot {
  const WeatherSnapshot({
    required this.temperatureC,
    required this.apparentC,
    required this.humidityPct,
    required this.windKmh,
    required this.label,
    required this.isLive,
  });

  final double temperatureC;
  final double apparentC;
  final int humidityPct;
  final double windKmh;
  final String label;
  final bool isLive;
}
