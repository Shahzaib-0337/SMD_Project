class Place {
  const Place({
    required this.id,
    required this.apiTitle,
    required this.displayTitle,
    required this.location,
    required this.imageUrl,
    required this.thumbnailUrl,
    required this.albumId,
    required this.latitude,
    required this.longitude,
    required this.description,
    required this.region,
  });

  final int id;
  final String apiTitle;
  final String displayTitle;
  final String location;
  final String imageUrl;
  final String thumbnailUrl;
  final int albumId;
  final double latitude;
  final double longitude;
  final String description;
  final String region;

  String get heroTag => 'place-hero-$id';

  Map<String, dynamic> toJson() => {
        'id': id,
        'apiTitle': apiTitle,
        'displayTitle': displayTitle,
        'location': location,
        'imageUrl': imageUrl,
        'thumbnailUrl': thumbnailUrl,
        'albumId': albumId,
        'latitude': latitude,
        'longitude': longitude,
        'description': description,
        'region': region,
      };

  factory Place.fromJson(Map<String, dynamic> json) {
    return Place(
      id: json['id'] as int,
      apiTitle: json['apiTitle'] as String,
      displayTitle: json['displayTitle'] as String,
      location: json['location'] as String,
      imageUrl: json['imageUrl'] as String,
      thumbnailUrl: json['thumbnailUrl'] as String,
      albumId: json['albumId'] as int,
      latitude: (json['latitude'] as num).toDouble(),
      longitude: (json['longitude'] as num).toDouble(),
      description: json['description'] as String,
      region: json['region'] as String,
    );
  }
}
