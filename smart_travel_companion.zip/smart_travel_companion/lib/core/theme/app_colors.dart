import 'package:flutter/material.dart';

abstract final class AppColors {
  static const Color primary = Color(0xFF6C63FF);
  static const Color accentRed = Color(0xFFFF6B6B);
  static const Color accentGreen = Color(0xFF22C55E);
  static const Color accentOrange = Color(0xFFF59E0B);
  static const Color lightBg = Color(0xFFF8FAFC);
  static const Color darkBg = Color(0xFF0F172A);
  static const Color darkSurface = Color(0xFF1E293B);
  static const Color muted = Color(0xFF94A3B8);
  static const Color chipInactiveLight = Color(0xFFE2E8F0);
  static const Color chipInactiveDark = Color(0xFF334155);
  static const Color weatherCardLight = Color(0xFFF1F5F9);
  static const Color weatherCardDark = Color(0xFF1E293B);
}
