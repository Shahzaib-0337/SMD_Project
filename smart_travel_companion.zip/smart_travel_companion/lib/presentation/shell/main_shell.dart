import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../core/theme/app_colors.dart';
import '../widgets/app_drawer.dart';

class MainShell extends StatelessWidget {
  const MainShell({super.key, required this.navigationShell});

  final StatefulNavigationShell navigationShell;

  void _goBranch(int index) {
    navigationShell.goBranch(
      index,
      initialLocation: index == navigationShell.currentIndex,
    );
  }

  @override
  Widget build(BuildContext context) {
    final idx = navigationShell.currentIndex;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final barColor = isDark ? AppColors.darkSurface : Colors.white;

    return Scaffold(
      extendBody: true,
      drawer: const AppDrawer(),
      body: Padding(
        padding: const EdgeInsets.only(bottom: 92),
        child: navigationShell,
      ),
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
        child: Stack(
          clipBehavior: Clip.none,
          alignment: Alignment.topCenter,
          children: [
            Material(
              elevation: 14,
              shadowColor: Colors.black.withValues(alpha: 0.12),
              borderRadius: BorderRadius.circular(28),
              color: barColor,
              child: SafeArea(
                top: false,
                minimum: EdgeInsets.zero,
                child: SizedBox(
                  height: 66,
                  child: Row(
                    children: [
                      _NavItem(
                        icon: Icons.home_outlined,
                        label: 'Home',
                        selected: idx == 0,
                        onTap: () => _goBranch(0),
                      ),
                      _NavItem(
                        icon: Icons.map_outlined,
                        label: 'Map',
                        selected: idx == 1,
                        onTap: () => _goBranch(1),
                      ),
                      const SizedBox(width: 56),
                      _NavItem(
                        icon: Icons.favorite_border,
                        label: 'Favorites',
                        selected: idx == 2,
                        onTap: () => _goBranch(2),
                      ),
                      _NavItem(
                        icon: Icons.person_outline,
                        label: 'Profile',
                        selected: idx == 3,
                        onTap: () => _goBranch(3),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Positioned(
              top: -26,
              child: Material(
                elevation: 8,
                shadowColor: Colors.black26,
                shape: const CircleBorder(),
                color: Theme.of(context).colorScheme.primary,
                child: InkWell(
                  customBorder: const CircleBorder(),
                  onTap: () => context.push('/search'),
                  child: const SizedBox(
                    width: 58,
                    height: 58,
                    child: Icon(Icons.add, color: Colors.white, size: 28),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _NavItem extends StatelessWidget {
  const _NavItem({
    required this.icon,
    required this.label,
    required this.selected,
    required this.onTap,
  });

  final IconData icon;
  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final primary = Theme.of(context).colorScheme.primary;
    final idle = Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.55);
    final color = selected ? primary : idle;

    return Expanded(
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 8),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, color: color, size: 24),
              const SizedBox(height: 2),
              Text(
                label,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  fontSize: 11,
                  fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
                  color: color,
                ),
              ),
              const SizedBox(height: 4),
              AnimatedContainer(
                duration: const Duration(milliseconds: 220),
                curve: Curves.easeOutCubic,
                height: 3,
                width: selected ? 22 : 0,
                decoration: BoxDecoration(
                  color: primary,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
