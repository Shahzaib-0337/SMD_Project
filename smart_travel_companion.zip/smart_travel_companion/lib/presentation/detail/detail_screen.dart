import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../core/theme/app_colors.dart';
import '../../models/place.dart';
import '../../providers/app_settings_providers.dart';
import '../../providers/weather_providers.dart';
import '../../models/weather_snapshot.dart';

class DetailScreen extends ConsumerStatefulWidget {
  const DetailScreen({super.key, required this.place});

  final Place place;

  @override
  ConsumerState<DetailScreen> createState() => _DetailScreenState();
}

class _DetailScreenState extends ConsumerState<DetailScreen> {
  bool _aboutExpanded = false;

  @override
  void initState() {
    super.initState();
    Future.microtask(() {
      ref.read(recentPlaceIdsProvider.notifier).recordOpened(widget.place.id);
    });
  }

  Future<void> _openMaps() async {
    final uri = Uri.parse(
      'https://www.google.com/maps/search/?api=1&query=${widget.place.latitude},${widget.place.longitude}',
    );
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Could not open Maps')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final place = widget.place;
    final favs = ref.watch(favoritesIdsProvider);
    final isFav = favs.contains(place.id);
    final weather = ref.watch(weatherForPlaceProvider(place));
    final scheme = Theme.of(context).colorScheme;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final overlayCircle = isDark
        ? scheme.surfaceContainerHigh.withValues(alpha: 0.96)
        : Colors.white.withValues(alpha: 0.94);
    final overlayIcon = scheme.onSurface.withValues(alpha: isDark ? 0.92 : 0.82);
    final heartColor = isFav ? AppColors.accentRed : overlayIcon;

    return Scaffold(
      body: Stack(
        children: [
          CustomScrollView(
            slivers: [
              SliverAppBar(
                pinned: true,
                stretch: true,
                expandedHeight: 286,
                backgroundColor: Theme.of(context).scaffoldBackgroundColor,
                elevation: 0,
                leadingWidth: 52,
                leading: Padding(
                  padding: const EdgeInsets.all(8),
                  child: Material(
                    color: overlayCircle,
                    shape: const CircleBorder(),
                    child: InkWell(
                      customBorder: const CircleBorder(),
                      onTap: () => context.pop(),
                      child: Center(
                        child: Icon(
                          Icons.arrow_back_ios_new_rounded,
                          size: 16,
                          color: overlayIcon,
                        ),
                      ),
                    ),
                  ),
                ),
                actions: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(0, 8, 12, 8),
                    child: Material(
                      color: overlayCircle,
                      shape: const CircleBorder(),
                      child: InkWell(
                        customBorder: const CircleBorder(),
                        onTap: () => ref.read(favoritesIdsProvider.notifier).toggle(place.id),
                        child: SizedBox(
                          width: 44,
                          height: 44,
                          child: Icon(
                            isFav ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                            color: heartColor,
                            size: 22,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
                flexibleSpace: FlexibleSpaceBar(
                  collapseMode: CollapseMode.parallax,
                  background: Stack(
                    fit: StackFit.expand,
                    children: [
                      Hero(
                        tag: place.heroTag,
                        child: CachedNetworkImage(
                          imageUrl: place.imageUrl,
                          fit: BoxFit.cover,
                          width: double.infinity,
                          placeholder: (context, url) => Container(color: Colors.grey.shade300),
                          errorWidget: (context, url, _) =>
                              Container(color: Colors.grey.shade400, child: const Icon(Icons.broken_image)),
                        ),
                      ),
                      Positioned(
                        left: 0,
                        right: 0,
                        bottom: 20,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: List.generate(
                            3,
                            (i) => Container(
                              margin: const EdgeInsets.symmetric(horizontal: 4),
                              width: i == 0 ? 8 : 7,
                              height: 7,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: i == 0 ? Colors.white : Colors.white.withValues(alpha: 0.42),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              SliverToBoxAdapter(
                child: Transform.translate(
                  offset: const Offset(0, -18),
                  child: Material(
                    color: Theme.of(context).scaffoldBackgroundColor,
                    borderRadius: const BorderRadius.vertical(top: Radius.circular(22)),
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(20, 24, 20, 120),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            place.displayTitle,
                            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                                  fontWeight: FontWeight.bold,
                                ),
                          ),
                          const SizedBox(height: 8),
                          Row(
                            children: [
                              const Icon(Icons.place_rounded, size: 20, color: AppColors.primary),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Text(
                                  place.location,
                                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                                        color: AppColors.muted,
                                      ),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 12),
                          Text(
                            place.description,
                            style: Theme.of(context).textTheme.bodyMedium,
                          ),
                          const SizedBox(height: 18),
                          AnimatedSwitcher(
                            duration: const Duration(milliseconds: 320),
                            switchInCurve: Curves.easeOut,
                            switchOutCurve: Curves.easeIn,
                            child: weather.when(
                              data: (w) => _WeatherPanel(key: const ValueKey('ok'), snapshot: w),
                              loading: () => const _WeatherLoading(key: ValueKey('loading')),
                              error: (e, _) => _WeatherError(
                                key: const ValueKey('err'),
                                message: e.toString(),
                                onRetry: () => ref.invalidate(weatherForPlaceProvider(place)),
                              ),
                            ),
                          ),
                          const SizedBox(height: 18),
                          InkWell(
                            onTap: () => setState(() => _aboutExpanded = !_aboutExpanded),
                            borderRadius: BorderRadius.circular(12),
                            child: Padding(
                              padding: const EdgeInsets.symmetric(vertical: 8),
                              child: Row(
                                children: [
                                  Text(
                                    'About the place',
                                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                                          fontWeight: FontWeight.w700,
                                        ),
                                  ),
                                  const Spacer(),
                                  AnimatedRotation(
                                    turns: _aboutExpanded ? 0.5 : 0,
                                    duration: const Duration(milliseconds: 240),
                                    child: const Icon(Icons.expand_more),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          AnimatedSize(
                            duration: const Duration(milliseconds: 320),
                            curve: Curves.easeInOut,
                            alignment: Alignment.topCenter,
                            child: ConstrainedBox(
                              constraints: const BoxConstraints(),
                              child: Text(
                                _aboutExpanded
                                    ? '${place.description}\n\n'
                                        'Travel tips: pack layers, respect local trails, and leave no trace. '
                                        'This itinerary is a demo powered by JSONPlaceholder imagery and Open‑Meteo weather.'
                                    : '${_shortBlurb(place.description)}…',
                                style: Theme.of(context).textTheme.bodyMedium?.copyWith(height: 1.45),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
          Positioned(
            left: 16,
            right: 16,
            bottom: 24,
            child: SafeArea(
              top: false,
              child: FilledButton.icon(
                onPressed: _openMaps,
                icon: const Icon(Icons.map_outlined),
                label: const Text('View on Map'),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

String _shortBlurb(String text) {
  final parts = text.split('.');
  if (parts.isEmpty) return text;
  final first = parts.first.trim();
  return first.isEmpty ? text : first;
}

class _WeatherLoading extends StatelessWidget {
  const _WeatherLoading({super.key});

  @override
  Widget build(BuildContext context) {
    return const SizedBox(
      height: 120,
      child: Center(child: CircularProgressIndicator()),
    );
  }
}

class _WeatherError extends StatelessWidget {
  const _WeatherError({super.key, required this.message, required this.onRetry});

  final String message;
  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Weather unavailable'),
            const SizedBox(height: 8),
            Text(message, style: Theme.of(context).textTheme.bodySmall),
            const SizedBox(height: 12),
            OutlinedButton(onPressed: onRetry, child: const Text('Retry')),
          ],
        ),
      ),
    );
  }
}

class _WeatherPanel extends StatelessWidget {
  const _WeatherPanel({super.key, required this.snapshot});

  final WeatherSnapshot snapshot;

  @override
  Widget build(BuildContext context) {
    final w = snapshot;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final bg = isDark ? AppColors.weatherCardDark : AppColors.weatherCardLight;

    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(18),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: isDark ? 0.2 : 0.04),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      padding: const EdgeInsets.all(18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(
                'Current Weather',
                style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700),
              ),
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: AppColors.accentGreen.withValues(alpha: 0.15),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Row(
                  children: [
                    Container(
                      width: 6,
                      height: 6,
                      decoration: const BoxDecoration(color: AppColors.accentGreen, shape: BoxShape.circle),
                    ),
                    const SizedBox(width: 6),
                    Text(
                      w.isLive ? 'Live' : 'Demo',
                      style: Theme.of(context).textTheme.labelSmall?.copyWith(
                            color: AppColors.accentGreen,
                            fontWeight: FontWeight.w700,
                          ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Text(
                '${w.temperatureC.round()}°C',
                style: Theme.of(context).textTheme.displaySmall?.copyWith(fontWeight: FontWeight.bold),
              ),
              const SizedBox(width: 12),
              const Icon(Icons.wb_sunny_rounded, color: AppColors.accentOrange, size: 40),
              const Spacer(),
              Text(
                w.label,
                style: Theme.of(context).textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w600),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              _miniStat(context, 'Wind', '${w.windKmh.toStringAsFixed(0)} km/h'),
              _miniStat(context, 'Humidity', '${w.humidityPct}%'),
              _miniStat(context, 'Feels like', '${w.apparentC.round()}°C'),
            ],
          ),
        ],
      ),
    );
  }

  Widget _miniStat(BuildContext context, String k, String v) {
    return Expanded(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(k, style: Theme.of(context).textTheme.labelSmall?.copyWith(color: AppColors.muted)),
          const SizedBox(height: 4),
          Text(v, style: Theme.of(context).textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w700)),
        ],
      ),
    );
  }
}
