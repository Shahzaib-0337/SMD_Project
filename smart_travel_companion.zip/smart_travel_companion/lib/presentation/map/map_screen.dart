import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:latlong2/latlong.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../core/theme/app_colors.dart';
import '../../models/place.dart';
import '../../providers/places_providers.dart';

/// In-app map using [flutter_map] + OpenStreetMap tiles (no API key).
/// True HTML iframes are web-only; this works on mobile and web.
class MapScreen extends ConsumerWidget {
  const MapScreen({super.key});

  static const _userAgent = 'com.smarttravel.smart_travel_companion';

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final places = ref.watch(placesListProvider).items;
    final mapKey = ValueKey(
      places.isEmpty ? 'empty' : '${places.length}_${places.first.id}_${places.last.id}',
    );

    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 8, 20, 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              IconButton(
                icon: const Icon(Icons.menu_rounded),
                onPressed: () => Scaffold.of(context).openDrawer(),
              ),
              Expanded(
                child: Text(
                  'Map',
                  textAlign: TextAlign.center,
                  style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w700),
                ),
              ),
              const SizedBox(width: 48),
            ],
          ),
          const SizedBox(height: 4),
          Text(
            places.isEmpty
                ? 'Load places on Home, then pins appear here. Pan and pinch to explore.'
                : '${places.length} loaded places · tap a pin for details',
            style: Theme.of(context).textTheme.bodySmall?.copyWith(color: AppColors.muted),
          ),
          const SizedBox(height: 12),
          Expanded(
            child: ClipRRect(
              borderRadius: BorderRadius.circular(18),
              child: ColoredBox(
                color: Theme.of(context).colorScheme.surfaceContainerHighest.withValues(alpha: 0.35),
                child: places.isEmpty
                    ? Center(
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(Icons.map_outlined, size: 64, color: AppColors.primary.withValues(alpha: 0.4)),
                            const SizedBox(height: 12),
                            Text(
                              'No coordinates yet',
                              style: Theme.of(context).textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w600),
                            ),
                            const SizedBox(height: 8),
                            Text(
                              'Pull to refresh on Home or wait for the list to load.',
                              textAlign: TextAlign.center,
                              style: Theme.of(context).textTheme.bodySmall?.copyWith(color: AppColors.muted),
                            ),
                          ],
                        ),
                      )
                    : FlutterMap(
                        key: mapKey,
                        options: _mapOptions(places),
                        children: [
                          TileLayer(
                            urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                            userAgentPackageName: _userAgent,
                            maxNativeZoom: 19,
                          ),
                          MarkerLayer(
                            markers: [
                              for (final p in places)
                                Marker(
                                  point: LatLng(p.latitude, p.longitude),
                                  width: 40,
                                  height: 40,
                                  alignment: Alignment.bottomCenter,
                                  child: _PlacePin(
                                    place: p,
                                    onTap: () => context.push('/detail', extra: p),
                                  ),
                                ),
                            ],
                          ),
                          SimpleAttributionWidget(
                            source: const Text('OpenStreetMap'),
                            onTap: () => launchUrl(Uri.parse('https://openstreetmap.org/copyright')),
                            alignment: Alignment.bottomRight,
                            backgroundColor: Theme.of(context).colorScheme.surface.withValues(alpha: 0.92),
                          ),
                        ],
                      ),
              ),
            ),
          ),
          const SizedBox(height: 12),
          if (places.isNotEmpty)
            FilledButton.icon(
              onPressed: () async {
                final p = places.first;
                final uri = Uri.parse(
                  'https://www.google.com/maps/search/?api=1&query=${p.latitude},${p.longitude}',
                );
                await launchUrl(uri, mode: LaunchMode.externalApplication);
              },
              icon: const Icon(Icons.open_in_new_rounded),
              label: Text('Open ${places.first.displayTitle} externally'),
            ),
        ],
      ),
    );
  }

  MapOptions _mapOptions(List<Place> places) {
    if (places.length == 1) {
      final p = places.first;
      return MapOptions(
        initialCenter: LatLng(p.latitude, p.longitude),
        initialZoom: 11,
        minZoom: 3,
        maxZoom: 18,
        interactionOptions: const InteractionOptions(
          flags: InteractiveFlag.all & ~InteractiveFlag.rotate,
        ),
        backgroundColor: const Color(0xFFE8EEF4),
      );
    }

    final coords = places.map((e) => LatLng(e.latitude, e.longitude)).toList();
    return MapOptions(
      initialCameraFit: CameraFit.coordinates(
        coordinates: coords,
        padding: const EdgeInsets.all(48),
        maxZoom: 12,
      ),
      minZoom: 2,
      maxZoom: 18,
      interactionOptions: const InteractionOptions(
        flags: InteractiveFlag.all & ~InteractiveFlag.rotate,
      ),
      backgroundColor: const Color(0xFFE8EEF4),
    );
  }
}

class _PlacePin extends StatelessWidget {
  const _PlacePin({required this.place, required this.onTap});

  final Place place;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Tooltip(
        message: place.displayTitle,
        child: Icon(
          Icons.location_on_rounded,
          size: 40,
          color: AppColors.primary,
          shadows: const [
            Shadow(color: Colors.black26, blurRadius: 4, offset: Offset(0, 2)),
          ],
        ),
      ),
    );
  }
}
