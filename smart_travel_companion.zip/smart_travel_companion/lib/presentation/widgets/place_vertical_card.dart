import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/theme/app_colors.dart';
import '../../models/place.dart';
import '../../providers/app_settings_providers.dart';

class PlaceVerticalCard extends ConsumerWidget {
  const PlaceVerticalCard({
    super.key,
    required this.place,
    required this.onTap,
    this.opacity = 1,
  });

  final Place place;
  final VoidCallback onTap;
  final double opacity;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final favs = ref.watch(favoritesIdsProvider);
    final isFav = favs.contains(place.id);
    return AnimatedOpacity(
      duration: const Duration(milliseconds: 280),
      opacity: opacity,
      curve: Curves.easeOut,
      child: Padding(
        padding: const EdgeInsets.only(bottom: 18),
        child: Material(
          color: Theme.of(context).cardColor,
          borderRadius: BorderRadius.circular(20),
          clipBehavior: Clip.antiAlias,
          elevation: 3,
          shadowColor: Colors.black.withValues(alpha: 0.08),
          child: InkWell(
            onTap: onTap,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Hero(
                  tag: place.heroTag,
                  child: AspectRatio(
                    aspectRatio: 16 / 11,
                    child: ClipRRect(
                      borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
                      child: CachedNetworkImage(
                        imageUrl: place.imageUrl,
                        fit: BoxFit.cover,
                        placeholder: (context, url) => Container(color: Colors.grey.shade200),
                        errorWidget: (context, url, _) =>
                            Container(color: Colors.grey.shade300, child: const Icon(Icons.broken_image)),
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 14, 12, 16),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              place.displayTitle,
                              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                                    fontWeight: FontWeight.w700,
                                  ),
                            ),
                            const SizedBox(height: 6),
                            Text(
                              place.location,
                              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                                    color: AppColors.muted,
                                    fontWeight: FontWeight.w500,
                                  ),
                            ),
                          ],
                        ),
                      ),
                      IconButton(
                        style: IconButton.styleFrom(
                          backgroundColor: Theme.of(context).brightness == Brightness.dark
                              ? AppColors.chipInactiveDark
                              : AppColors.chipInactiveLight,
                        ),
                        onPressed: () => ref.read(favoritesIdsProvider.notifier).toggle(place.id),
                        icon: Icon(
                          isFav ? Icons.favorite : Icons.favorite_border,
                          color: isFav ? AppColors.accentRed : AppColors.muted,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
