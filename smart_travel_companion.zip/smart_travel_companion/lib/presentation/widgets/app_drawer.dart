import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/theme/app_colors.dart';
import '../../providers/app_settings_providers.dart';

class AppDrawer extends ConsumerWidget {
  const AppDrawer({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Drawer(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          DrawerHeader(
            decoration: const BoxDecoration(color: AppColors.primary),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const CircleAvatar(
                  radius: 32,
                  backgroundColor: Colors.white24,
                  child: Icon(Icons.person, size: 36, color: Colors.white),
                ),
                const SizedBox(height: 12),
                Text(
                  'Shahzaib',
                  style: Theme.of(context).textTheme.titleLarge?.copyWith(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                      ),
                ),
                Text(
                  'shahzaib@gmail.com',
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: Colors.white70,
                      ),
                ),
              ],
            ),
          ),
          _tile(context, Icons.home_outlined, 'Home', () {
            Navigator.pop(context);
            context.go('/home');
          }),
          _tile(context, Icons.map_outlined, 'Map', () {
            Navigator.pop(context);
            context.go('/map');
          }),
          _tile(context, Icons.favorite_border, 'Favorites', () {
            Navigator.pop(context);
            context.go('/favorites');
          }),
          _tile(context, Icons.download_outlined, 'Downloaded', () {
            Navigator.pop(context);
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Offline cache is updated automatically.')),
            );
          }),
          _tile(context, Icons.settings_outlined, 'Settings', () {
            Navigator.pop(context);
            context.go('/profile');
          }),
          _tile(context, Icons.help_outline, 'Help & Support', () {
            Navigator.pop(context);
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Help: use pull-to-refresh and Retry on errors.')),
            );
          }),
          _tile(context, Icons.info_outline, 'About Us', () {
            Navigator.pop(context);
            showAboutDialog(
              context: context,
              applicationName: 'Smart Travel Companion',
              applicationVersion: '1.0.0',
              applicationLegalese: 'Demo UI for coursework.',
            );
          }),
          const Spacer(),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                const Icon(Icons.dark_mode_outlined),
                const SizedBox(width: 12),
                const Text('Dark Mode'),
                const Spacer(),
                Switch(
                  value: isDark,
                  onChanged: (_) async {
                    await ref.read(themeModeProvider.notifier).toggleDarkLight();
                  },
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _tile(BuildContext context, IconData icon, String label, VoidCallback onTap) {
    return ListTile(
      leading: Icon(icon),
      title: Text(label),
      onTap: onTap,
    );
  }
}
