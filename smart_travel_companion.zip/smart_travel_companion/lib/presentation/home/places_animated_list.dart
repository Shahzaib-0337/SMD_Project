import 'package:flutter/material.dart';

import '../../models/place.dart';
import '../widgets/place_vertical_card.dart';

/// Staggered [AnimatedList] for place cards (assignment requirement).
class PlacesAnimatedList extends StatefulWidget {
  const PlacesAnimatedList({
    super.key,
    required this.places,
    required this.onOpen,
    this.scrollController,
  });

  final List<Place> places;
  final void Function(Place) onOpen;
  final ScrollController? scrollController;

  @override
  State<PlacesAnimatedList> createState() => _PlacesAnimatedListState();
}

class _PlacesAnimatedListState extends State<PlacesAnimatedList> {
  final GlobalKey<AnimatedListState> _listKey = GlobalKey<AnimatedListState>();
  final List<Place> _rows = [];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _bootstrap());
  }

  Future<void> _bootstrap() async {
    for (var i = 0; i < widget.places.length; i++) {
      if (!mounted) return;
      _rows.add(widget.places[i]);
      _listKey.currentState?.insertItem(
        i,
        duration: const Duration(milliseconds: 320),
      );
      await Future<void>.delayed(const Duration(milliseconds: 16));
    }
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedList(
      key: _listKey,
      controller: widget.scrollController,
      initialItemCount: 0,
      padding: const EdgeInsets.fromLTRB(20, 0, 20, 8),
      itemBuilder: (context, index, animation) {
        final place = _rows[index];
        return SlideTransition(
          position: animation.drive(
            Tween(begin: const Offset(0, 0.06), end: Offset.zero)
                .chain(CurveTween(curve: Curves.easeOutCubic)),
          ),
          child: FadeTransition(
            opacity: animation,
            child: PlaceVerticalCard(
              place: place,
              onTap: () => widget.onOpen(place),
            ),
          ),
        );
      },
    );
  }
}
