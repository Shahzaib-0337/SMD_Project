import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/theme/app_colors.dart';
import '../../models/place.dart';
import '../../providers/places_providers.dart';
import 'places_animated_list.dart';

class HomeScreen extends ConsumerStatefulWidget {
  const HomeScreen({super.key});

  @override
  ConsumerState<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends ConsumerState<HomeScreen> {
  final _searchCtrl = TextEditingController();
  Timer? _debounce;
  final _scroll = ScrollController();

  @override
  void initState() {
    super.initState();
    _scroll.addListener(_onScroll);
    _searchCtrl.text = ref.read(homeSearchQueryProvider);
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _searchCtrl.dispose();
    _scroll.removeListener(_onScroll);
    _scroll.dispose();
    super.dispose();
  }

  void _onScroll() {
    if (!_scroll.hasClients) return;
    final max = _scroll.position.maxScrollExtent;
    if (max == 0) return;
    if (_scroll.offset > max - 360) {
      ref.read(placesListProvider.notifier).loadMore();
    }
  }

  void _onSearchChanged(String v) {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 420), () {
      ref.read(homeSearchQueryProvider.notifier).state = v;
    });
  }

  @override
  Widget build(BuildContext context) {
    ref.listen<String>(homeSearchQueryProvider, (prev, next) {
      if (_searchCtrl.text != next) {
        _searchCtrl.value = TextEditingValue(
          text: next,
          selection: TextSelection.collapsed(offset: next.length),
        );
      }
    });

    final listState = ref.watch(placesListProvider);
    final chip = ref.watch(homeChipProvider);
    final query = ref.watch(homeSearchQueryProvider);
    final visible = ref.watch(visiblePlacesProvider);

    final listKey = Object.hash(
      listState.epoch,
      chip.name,
      query,
      visible.length,
      visible.isNotEmpty ? visible.first.id : -1,
    );

    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 12, 12, 0),
          child: Row(
            children: [
              IconButton(
                icon: const Icon(Icons.menu_rounded),
                onPressed: () => Scaffold.of(context).openDrawer(),
              ),
              Expanded(
                child: Text(
                  'Explore Places',
                  textAlign: TextAlign.center,
                  style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w700),
                ),
              ),
              IconButton(
                icon: const Icon(Icons.notifications_none_rounded),
                onPressed: () {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('No new notifications')),
                  );
                },
              ),
            ],
          ),
        ),
        if (listState.isOffline || listState.fromCache)
          AnimatedOpacity(
            duration: const Duration(milliseconds: 350),
            opacity: listState.isOffline ? 1 : 0.9,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(20, 8, 20, 4),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                decoration: BoxDecoration(
                  color: AppColors.accentOrange.withValues(alpha: 0.12),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.wifi_off_rounded, color: AppColors.accentOrange, size: 22),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        listState.fromCache
                            ? 'Showing cached places (offline or limited connection).'
                            : 'Limited connection.',
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(fontWeight: FontWeight.w500),
                      ),
                    ),
                    TextButton(
                      onPressed: () => ref.read(placesListProvider.notifier).refresh(),
                      child: const Text('Retry'),
                    ),
                  ],
                ),
              ),
            ),
          ),
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 12, 20, 8),
          child: Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _searchCtrl,
                  onChanged: _onSearchChanged,
                  decoration: InputDecoration(
                    hintText: 'Search places...',
                    hintStyle: TextStyle(
                      color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.45),
                    ),
                    prefixIcon: Icon(
                      Icons.search_rounded,
                      color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.45),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Material(
                color: isDark ? AppColors.chipInactiveDark : AppColors.chipInactiveLight,
                borderRadius: BorderRadius.circular(14),
                child: InkWell(
                  borderRadius: BorderRadius.circular(14),
                  onTap: () => context.push('/search'),
                  child: const SizedBox(
                    width: 52,
                    height: 52,
                    child: Icon(Icons.tune_rounded),
                  ),
                ),
              ),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 10),
          child: Row(
            children: [
              Expanded(
                child: _HomeChipSegment(
                  label: 'All',
                  selected: chip == HomeChip.all,
                  isDark: isDark,
                  onTap: () => ref.read(homeChipProvider.notifier).state = HomeChip.all,
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _HomeChipSegment(
                  label: 'Favorites',
                  selected: chip == HomeChip.favorites,
                  isDark: isDark,
                  onTap: () => ref.read(homeChipProvider.notifier).state = HomeChip.favorites,
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _HomeChipSegment(
                  label: 'Recent',
                  selected: chip == HomeChip.recent,
                  isDark: isDark,
                  onTap: () => ref.read(homeChipProvider.notifier).state = HomeChip.recent,
                ),
              ),
            ],
          ),
        ),
        Expanded(
          child: RefreshIndicator(
            onRefresh: () => ref.read(placesListProvider.notifier).refresh(),
            child: _HomeBody(
              listState: listState,
              visible: visible,
              listKey: listKey,
              scroll: _scroll,
              onOpen: (place) => context.push('/detail', extra: place),
              onRetry: () => ref.read(placesListProvider.notifier).refresh(),
              onClearFilters: () {
                _searchCtrl.clear();
                ref.read(homeSearchQueryProvider.notifier).state = '';
                ref.read(homeChipProvider.notifier).state = HomeChip.all;
              },
            ),
          ),
        ),
      ],
    );
  }
}

class _HomeChipSegment extends StatelessWidget {
  const _HomeChipSegment({
    required this.label,
    required this.selected,
    required this.isDark,
    required this.onTap,
  });

  final String label;
  final bool selected;
  final bool isDark;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final inactiveBg = isDark ? AppColors.chipInactiveDark : AppColors.chipInactiveLight;
    final inactiveFg = isDark ? AppColors.muted : const Color(0xFF475569);

    return AnimatedContainer(
      duration: const Duration(milliseconds: 220),
      curve: Curves.easeOutCubic,
      height: 44,
      decoration: BoxDecoration(
        color: selected ? AppColors.primary : inactiveBg,
        borderRadius: BorderRadius.circular(22),
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(22),
          child: Center(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 6),
              child: Text(
                label,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.labelLarge?.copyWith(
                      color: selected ? Colors.white : inactiveFg,
                      fontWeight: FontWeight.w700,
                      fontSize: 13,
                    ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _HomeBody extends StatelessWidget {
  const _HomeBody({
    required this.listState,
    required this.visible,
    required this.listKey,
    required this.scroll,
    required this.onOpen,
    required this.onRetry,
    required this.onClearFilters,
  });

  final PlacesListState listState;
  final List<Place> visible;
  final int listKey;
  final ScrollController scroll;
  final void Function(Place) onOpen;
  final VoidCallback onRetry;
  final VoidCallback onClearFilters;

  @override
  Widget build(BuildContext context) {
    if (listState.isLoading && listState.items.isEmpty) {
      return ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        children: const [
          SizedBox(height: 120),
          Center(child: CircularProgressIndicator()),
        ],
      );
    }
    if (listState.errorMessage != null && listState.items.isEmpty) {
      return ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        children: [
          const SizedBox(height: 48),
          _ErrorEmpty(
            message: listState.errorMessage!,
            isOffline: listState.isOffline,
            onRetry: onRetry,
          ),
        ],
      );
    }
    if (visible.isEmpty) {
      return ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        children: [
          const SizedBox(height: 40),
          _EmptyFilters(onClear: onClearFilters),
        ],
      );
    }
    return PlacesAnimatedList(
      key: ValueKey(listKey),
      places: visible,
      scrollController: scroll,
      onOpen: onOpen,
    );
  }
}

class _EmptyFilters extends StatelessWidget {
  const _EmptyFilters({required this.onClear});

  final VoidCallback onClear;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 28),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 120,
            height: 120,
            decoration: BoxDecoration(
              color: AppColors.primary.withValues(alpha: 0.12),
              shape: BoxShape.circle,
            ),
            child: Icon(
              Icons.search_rounded,
              size: 56,
              color: AppColors.primary.withValues(alpha: 0.55),
            ),
          ),
          const SizedBox(height: 20),
          Text(
            'No places found',
            style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 10),
          Text(
            'Try adjusting your search or filter to find what you\'re looking for.',
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  color: AppColors.muted,
                  height: 1.45,
                ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 28),
          SizedBox(
            width: double.infinity,
            child: FilledButton(
              onPressed: onClear,
              child: const Text('Clear Filters'),
            ),
          ),
        ],
      ),
    );
  }
}

class _ErrorEmpty extends StatelessWidget {
  const _ErrorEmpty({
    required this.message,
    required this.isOffline,
    required this.onRetry,
  });

  final String message;
  final bool isOffline;
  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 28),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 120,
            height: 120,
            decoration: BoxDecoration(
              color: AppColors.primary.withValues(alpha: 0.12),
              shape: BoxShape.circle,
            ),
            child: Icon(
              isOffline ? Icons.signal_wifi_off_rounded : Icons.cloud_off_outlined,
              size: 52,
              color: AppColors.primary.withValues(alpha: 0.55),
            ),
          ),
          const SizedBox(height: 20),
          Text(
            isOffline ? 'You\'re offline' : 'Something went wrong',
            style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 10),
          Text(
            isOffline
                ? 'No internet connection. Showing cached places when available.'
                : message,
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: AppColors.muted, height: 1.45),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 28),
          SizedBox(
            width: double.infinity,
            child: FilledButton(
              onPressed: onRetry,
              child: const Text('Retry'),
            ),
          ),
        ],
      ),
    );
  }
}
