import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/theme/app_colors.dart';
import '../../providers/places_providers.dart';
import '../widgets/place_horizontal_card.dart';

class SearchFilterScreen extends ConsumerStatefulWidget {
  const SearchFilterScreen({super.key});

  @override
  ConsumerState<SearchFilterScreen> createState() => _SearchFilterScreenState();
}

class _SearchFilterScreenState extends ConsumerState<SearchFilterScreen> {
  late final TextEditingController _searchCtrl;

  @override
  void initState() {
    super.initState();
    _searchCtrl = TextEditingController(text: ref.read(homeSearchQueryProvider));
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  void _clearAll() {
    _searchCtrl.clear();
    ref.read(homeSearchQueryProvider.notifier).state = '';
    ref.read(searchScreenSortProvider.notifier).state = SortBy.relevance;
    ref.read(searchScreenRegionProvider.notifier).state = null;
    ref.read(searchScreenShowFavoritesOnlyProvider.notifier).state = false;
  }

  @override
  Widget build(BuildContext context) {
    final sort = ref.watch(searchScreenSortProvider);
    final region = ref.watch(searchScreenRegionProvider);
    final favOnly = ref.watch(searchScreenShowFavoritesOnlyProvider);
    final results = ref.watch(searchResultsProvider);

    ref.listen<String>(homeSearchQueryProvider, (prev, next) {
      if (_searchCtrl.text != next) {
        _searchCtrl.value = TextEditingValue(
          text: next,
          selection: TextSelection.collapsed(offset: next.length),
        );
      }
    });

    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded),
          onPressed: () => context.pop(),
        ),
        title: const Text('Search & Filter'),
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 28),
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  'Filters',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800),
                ),
              ),
              TextButton(
                onPressed: _clearAll,
                child: const Text('Clear All'),
              ),
            ],
          ),
          const SizedBox(height: 8),
          TextField(
            controller: _searchCtrl,
            onChanged: (v) {
              ref.read(homeSearchQueryProvider.notifier).state = v;
              setState(() {});
            },
            decoration: InputDecoration(
              hintText: 'Search places...',
              prefixIcon: Icon(
                Icons.search_rounded,
                color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.45),
              ),
              suffixIcon: _searchCtrl.text.isEmpty
                  ? null
                  : IconButton(
                      icon: const Icon(Icons.close_rounded),
                      onPressed: () {
                        _searchCtrl.clear();
                        ref.read(homeSearchQueryProvider.notifier).state = '';
                        setState(() {});
                      },
                    ),
            ),
          ),
          const SizedBox(height: 22),
          Text(
            'Sort By',
            style: Theme.of(context).textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w700),
          ),
          const SizedBox(height: 8),
          DropdownButtonFormField<SortBy>(
            key: ValueKey(sort),
            initialValue: sort,
            decoration: const InputDecoration(contentPadding: EdgeInsets.symmetric(horizontal: 14, vertical: 4)),
            items: const [
              DropdownMenuItem(value: SortBy.relevance, child: Text('Recommended')),
              DropdownMenuItem(value: SortBy.nameAsc, child: Text('Name (A–Z)')),
              DropdownMenuItem(value: SortBy.nameDesc, child: Text('Name (Z–A)')),
            ],
            onChanged: (v) {
              if (v != null) ref.read(searchScreenSortProvider.notifier).state = v;
            },
          ),
          const SizedBox(height: 20),
          Text(
            'Show',
            style: Theme.of(context).textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w700),
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: _ShowPill(
                  label: 'All',
                  selected: !favOnly,
                  onTap: () => ref.read(searchScreenShowFavoritesOnlyProvider.notifier).state = false,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _ShowPill(
                  label: 'Favorites',
                  selected: favOnly,
                  onTap: () => ref.read(searchScreenShowFavoritesOnlyProvider.notifier).state = true,
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          Text(
            'Region',
            style: Theme.of(context).textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w700),
          ),
          const SizedBox(height: 8),
          DropdownButtonFormField<String>(
            key: ValueKey(region ?? 'All'),
            initialValue: region ?? 'All',
            decoration: const InputDecoration(contentPadding: EdgeInsets.symmetric(horizontal: 14, vertical: 4)),
            items: const [
              DropdownMenuItem(value: 'All', child: Text('All Regions')),
              DropdownMenuItem(value: 'Oceania', child: Text('Oceania')),
              DropdownMenuItem(value: 'Europe', child: Text('Europe')),
              DropdownMenuItem(value: 'Americas', child: Text('Americas')),
              DropdownMenuItem(value: 'Asia', child: Text('Asia')),
              DropdownMenuItem(value: 'Africa', child: Text('Africa')),
            ],
            onChanged: (v) {
              if (v == null) return;
              ref.read(searchScreenRegionProvider.notifier).state = v == 'All' ? null : v;
            },
          ),
          const SizedBox(height: 24),
          SizedBox(
            width: double.infinity,
            child: FilledButton(
              onPressed: () => context.pop(),
              child: const Text('Apply Filters'),
            ),
          ),
          const SizedBox(height: 28),
          if (results.isEmpty)
            Column(
              children: [
                Container(
                  width: 100,
                  height: 100,
                  decoration: BoxDecoration(
                    color: AppColors.primary.withValues(alpha: 0.1),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(Icons.search_rounded, size: 48, color: AppColors.primary.withValues(alpha: 0.45)),
                ),
                const SizedBox(height: 16),
                Text(
                  'No places found',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700),
                ),
                const SizedBox(height: 8),
                Text(
                  'Try clearing filters or widening your search.',
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(color: AppColors.muted),
                  textAlign: TextAlign.center,
                ),
              ],
            )
          else ...[
            Text(
              'Results',
              style: Theme.of(context).textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 12),
            ...results.map(
              (p) => PlaceHorizontalCard(
                place: p,
                onTap: () => context.push('/detail', extra: p),
              ),
            ),
          ],
        ],
      ),
    );
  }
}

class _ShowPill extends StatelessWidget {
  const _ShowPill({
    required this.label,
    required this.selected,
    required this.onTap,
  });

  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Material(
      color: selected
          ? AppColors.primary
          : (isDark ? AppColors.chipInactiveDark : AppColors.chipInactiveLight),
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 16),
          child: Center(
            child: Text(
              label,
              style: Theme.of(context).textTheme.titleSmall?.copyWith(
                    fontWeight: FontWeight.w700,
                    color: selected ? Colors.white : Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.75),
                  ),
            ),
          ),
        ),
      ),
    );
  }
}
