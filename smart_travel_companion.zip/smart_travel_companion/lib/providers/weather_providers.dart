import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../data/weather_repository.dart';
import '../models/place.dart';
import '../models/weather_snapshot.dart';

final weatherRepositoryProvider = Provider<WeatherRepository>((ref) {
  return WeatherRepository();
});

final weatherForPlaceProvider =
    FutureProvider.autoDispose.family<WeatherSnapshot, Place>((ref, place) async {
  final repo = ref.watch(weatherRepositoryProvider);
  return repo.fetchCurrent(latitude: place.latitude, longitude: place.longitude);
});
