import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

final sharedPreferencesProvider = FutureProvider<SharedPreferences>((ref) async {
  return SharedPreferences.getInstance();
});

final favoritesIdsProvider =
    NotifierProvider<FavoritesNotifier, Set<int>>(FavoritesNotifier.new);

class FavoritesNotifier extends Notifier<Set<int>> {
  static const _key = 'favorite_place_ids';

  @override
  Set<int> build() {
    Future.microtask(_load);
    return {};
  }

  Future<void> _load() async {
    final prefs = await ref.read(sharedPreferencesProvider.future);
    final raw = prefs.getStringList(_key) ?? [];
    state = raw.map(int.parse).toSet();
  }

  Future<void> _persist() async {
    final prefs = await ref.read(sharedPreferencesProvider.future);
    await prefs.setStringList(_key, state.map((e) => e.toString()).toList());
  }

  Future<void> toggle(int id) async {
    final next = Set<int>.from(state);
    if (next.contains(id)) {
      next.remove(id);
    } else {
      next.add(id);
    }
    state = next;
    await _persist();
  }

  bool isFavorite(int id) => state.contains(id);
}

final themeModeProvider = NotifierProvider<ThemeModeNotifier, ThemeMode>(
  ThemeModeNotifier.new,
);

class ThemeModeNotifier extends Notifier<ThemeMode> {
  static const _key = 'theme_mode';

  @override
  ThemeMode build() {
    Future.microtask(_load);
    return ThemeMode.system;
  }

  Future<void> _load() async {
    final prefs = await ref.read(sharedPreferencesProvider.future);
    final v = prefs.getString(_key);
    if (v == 'dark') {
      state = ThemeMode.dark;
    } else if (v == 'light') {
      state = ThemeMode.light;
    } else if (v == 'system') {
      state = ThemeMode.system;
    }
  }

  Future<void> setMode(ThemeMode mode) async {
    state = mode;
    final prefs = await ref.read(sharedPreferencesProvider.future);
    final s = switch (mode) {
      ThemeMode.dark => 'dark',
      ThemeMode.light => 'light',
      _ => 'system',
    };
    await prefs.setString(_key, s);
  }

  Future<void> toggleDarkLight() async {
    final next = state == ThemeMode.dark ? ThemeMode.light : ThemeMode.dark;
    await setMode(next);
  }
}

final recentPlaceIdsProvider =
    NotifierProvider<RecentPlacesNotifier, List<int>>(RecentPlacesNotifier.new);

class RecentPlacesNotifier extends Notifier<List<int>> {
  static const _key = 'recent_place_ids';
  static const _max = 30;

  @override
  List<int> build() {
    Future.microtask(_load);
    return const [];
  }

  Future<void> _load() async {
    final prefs = await ref.read(sharedPreferencesProvider.future);
    final raw = prefs.getStringList(_key) ?? [];
    state = raw.map(int.parse).toList();
  }

  Future<void> recordOpened(int id) async {
    final list = List<int>.from(state)..remove(id);
    list.insert(0, id);
    if (list.length > _max) list.removeRange(_max, list.length);
    state = list;
    final prefs = await ref.read(sharedPreferencesProvider.future);
    await prefs.setStringList(_key, list.map((e) => e.toString()).toList());
  }
}
