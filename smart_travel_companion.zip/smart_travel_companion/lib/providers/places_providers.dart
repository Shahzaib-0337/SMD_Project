import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'app_settings_providers.dart';
import '../data/places_repository.dart';
import '../models/place.dart';

final placesRepositoryProvider = Provider<PlacesRepository>((ref) {
  return PlacesRepository();
});

enum HomeChip { all, favorites, recent }

enum SortBy { relevance, nameAsc, nameDesc }

class PlacesListState {
  const PlacesListState({
    required this.items,
    required this.isLoading,
    required this.isLoadingMore,
    required this.hasMore,
    required this.errorMessage,
    required this.fromCache,
    required this.isOffline,
    required this.epoch,
  });

  final List<Place> items;
  final bool isLoading;
  final bool isLoadingMore;
  final bool hasMore;
  final String? errorMessage;
  final bool fromCache;
  final bool isOffline;
  final int epoch;

  static const initial = PlacesListState(
    items: [],
    isLoading: true,
    isLoadingMore: false,
    hasMore: true,
    errorMessage: null,
    fromCache: false,
    isOffline: false,
    epoch: 0,
  );

  PlacesListState copyWith({
    List<Place>? items,
    bool? isLoading,
    bool? isLoadingMore,
    bool? hasMore,
    String? errorMessage,
    bool? fromCache,
    bool? isOffline,
    int? epoch,
    bool clearError = false,
  }) {
    return PlacesListState(
      items: items ?? this.items,
      isLoading: isLoading ?? this.isLoading,
      isLoadingMore: isLoadingMore ?? this.isLoadingMore,
      hasMore: hasMore ?? this.hasMore,
      errorMessage: clearError ? null : (errorMessage ?? this.errorMessage),
      fromCache: fromCache ?? this.fromCache,
      isOffline: isOffline ?? this.isOffline,
      epoch: epoch ?? this.epoch,
    );
  }
}

final placesListProvider =
    NotifierProvider<PlacesListNotifier, PlacesListState>(PlacesListNotifier.new);

class PlacesListNotifier extends Notifier<PlacesListState> {
  static const _pageSize = 12;

  @override
  PlacesListState build() {
    Future.microtask(refresh);
    return PlacesListState.initial;
  }

  PlacesRepository get _repo => ref.read(placesRepositoryProvider);

  Future<void> refresh() async {
    state = PlacesListState(
      items: const [],
      isLoading: true,
      isLoadingMore: false,
      hasMore: true,
      errorMessage: null,
      fromCache: state.fromCache,
      isOffline: state.isOffline,
      epoch: state.epoch,
    );
    await _load(start: 0, append: false);
  }

  Future<void> loadMore() async {
    if (!state.hasMore || state.isLoadingMore || state.isLoading) return;
    state = state.copyWith(isLoadingMore: true);
    await _load(start: state.items.length, append: true);
  }

  Future<void> _load({required int start, required bool append}) async {
    try {
      final online = await _repo.hasConnection;
      final page = await _repo.fetchPage(start: start, limit: _pageSize);
      final merged = append ? [...state.items, ...page] : page;
      state = PlacesListState(
        items: merged,
        isLoading: false,
        isLoadingMore: false,
        hasMore: page.length >= _pageSize,
        errorMessage: null,
        fromCache: !online,
        isOffline: !online,
        epoch: append ? state.epoch : state.epoch + 1,
      );
    } on PlacesException catch (e) {
      state = state.copyWith(
        isLoading: false,
        isLoadingMore: false,
        errorMessage: e.message,
        isOffline: e.code == 'offline',
        clearError: false,
      );
    } catch (e) {
      state = state.copyWith(
        isLoading: false,
        isLoadingMore: false,
        errorMessage: e.toString(),
      );
    }
  }
}

final homeSearchQueryProvider = StateProvider<String>((ref) => '');

final homeChipProvider = StateProvider<HomeChip>((ref) => HomeChip.all);

final searchScreenSortProvider = StateProvider<SortBy>((ref) => SortBy.relevance);

final searchScreenRegionProvider = StateProvider<String?>((ref) => null);

final searchScreenShowFavoritesOnlyProvider = StateProvider<bool>((ref) => false);

/// All loaded + client-side filters for home & search UIs.
final visiblePlacesProvider = Provider<List<Place>>((ref) {
  final base = ref.watch(placesListProvider).items;
  final q = ref.watch(homeSearchQueryProvider).trim().toLowerCase();
  final chip = ref.watch(homeChipProvider);
  final favs = ref.watch(favoritesIdsProvider);
  final recent = ref.watch(recentPlaceIdsProvider);

  Iterable<Place> it = base;
  if (q.isNotEmpty) {
    it = it.where(
      (p) =>
          p.displayTitle.toLowerCase().contains(q) ||
          p.location.toLowerCase().contains(q) ||
          p.apiTitle.toLowerCase().contains(q),
    );
  }
  switch (chip) {
    case HomeChip.favorites:
      it = it.where((p) => favs.contains(p.id));
      break;
    case HomeChip.recent:
      final order = {for (var i = 0; i < recent.length; i++) recent[i]: i};
      final list = it.where((p) => order.containsKey(p.id)).toList();
      list.sort((a, b) => order[a.id]!.compareTo(order[b.id]!));
      return list;
    case HomeChip.all:
      break;
  }
  return it.toList();
});

final searchResultsProvider = Provider<List<Place>>((ref) {
  final base = ref.watch(placesListProvider).items;
  final q = ref.watch(homeSearchQueryProvider).trim().toLowerCase();
  final sort = ref.watch(searchScreenSortProvider);
  final region = ref.watch(searchScreenRegionProvider);
  final favOnly = ref.watch(searchScreenShowFavoritesOnlyProvider);
  final favs = ref.watch(favoritesIdsProvider);

  Iterable<Place> it = base;
  if (q.isNotEmpty) {
    it = it.where(
      (p) =>
          p.displayTitle.toLowerCase().contains(q) ||
          p.location.toLowerCase().contains(q),
    );
  }
  if (region != null && region != 'All') {
    it = it.where((p) => p.region == region);
  }
  if (favOnly) {
    it = it.where((p) => favs.contains(p.id));
  }
  var list = it.toList();
  switch (sort) {
    case SortBy.nameAsc:
      list.sort((a, b) => a.displayTitle.compareTo(b.displayTitle));
      break;
    case SortBy.nameDesc:
      list.sort((a, b) => b.displayTitle.compareTo(a.displayTitle));
      break;
    case SortBy.relevance:
      break;
  }
  return list;
});
