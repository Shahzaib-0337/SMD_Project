import 'dart:convert';

import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:http/http.dart' as http;

import '../models/place.dart';
import 'places_local_cache.dart';

/// Maps JSONPlaceholder photos into travel "places" with stable geo + copy.
class PlacesRepository {
  PlacesRepository({
    http.Client? httpClient,
    PlacesLocalCache? cache,
    Connectivity? connectivity,
  })  : _http = httpClient ?? http.Client(),
        _cache = cache ?? PlacesLocalCache(),
        _connectivity = connectivity ?? Connectivity();

  final http.Client _http;
  final PlacesLocalCache _cache;
  final Connectivity _connectivity;

  static const _base = 'https://jsonplaceholder.typicode.com/photos';

  Future<bool> get hasConnection async {
    final r = await _connectivity.checkConnectivity();
    if (r.isEmpty) return false;
    if (r.length == 1 && r.single == ConnectivityResult.none) return false;
    return true;
  }

  Future<List<Place>> fetchPage({
    required int start,
    required int limit,
  }) async {
    final online = await hasConnection;
    if (!online) {
      final cached = await _cache.loadPlaces();
      if (cached != null && cached.isNotEmpty) {
        return _slice(cached, start, limit);
      }
      throw const PlacesException('offline', 'No internet. No cached data yet.');
    }

    final uri = Uri.parse('$_base?_start=$start&_limit=$limit');
    final res = await _http.get(uri);
    if (res.statusCode != 200) {
      return _fallbackOrThrow('Server error (${res.statusCode})');
    }
    final list = jsonDecode(res.body) as List<dynamic>;
    final places = list
        .map((e) => _mapPhoto(Map<String, dynamic>.from(e as Map)))
        .toList();
    await _mergeCache(places);
    return places;
  }

  List<Place> _slice(List<Place> all, int start, int limit) {
    if (start >= all.length) return [];
    final end = (start + limit).clamp(0, all.length);
    return all.sublist(start, end);
  }

  Future<List<Place>> _fallbackOrThrow(String message) async {
    final cached = await _cache.loadPlaces();
    if (cached != null && cached.isNotEmpty) return cached;
    throw PlacesException('network', message);
  }

  /// Merges new page into cache file (dedupe by id).
  Future<void> _mergeCache(List<Place> page) async {
    final existing = await _cache.loadPlaces() ?? <Place>[];
    final byId = {for (final p in existing) p.id: p};
    for (final p in page) {
      byId[p.id] = p;
    }
    final merged = byId.values.toList()..sort((a, b) => a.id.compareTo(b.id));
    await _cache.savePlaces(merged);
  }

  Place _mapPhoto(Map<String, dynamic> json) {
    final id = json['id'] as int;
    final albumId = json['albumId'] as int;
    final title = (json['title'] as String?) ?? 'Place $id';
    final meta = _destinationForId(id);
    final desc =
        'Discover ${_shortTitle(title)} in ${meta.$2}. Ideal for photos, walks, and quiet moments. Album #$albumId from our curated picks inspired by community snapshots.';
    final rawUrl = json['url'] as String;
    final rawThumb = json['thumbnailUrl'] as String;
    return Place(
      id: id,
      apiTitle: title,
      displayTitle: meta.$1,
      location: meta.$2,
      // JSONPlaceholder still returns via.placeholder.com URLs (see API docs).
      // That host is often unreachable; keep the same photo id with a reliable CDN.
      imageUrl: _reliableImageUrl(rawUrl, id, 600, 400),
      thumbnailUrl: _reliableImageUrl(rawThumb, id, 150, 150),
      albumId: albumId,
      latitude: meta.$3,
      longitude: meta.$4,
      description: desc,
      region: meta.$5,
    );
  }

  /// Picsum gives a stable image per photo id; data still comes from jsonplaceholder.typicode.com/photos.
  String _reliableImageUrl(String apiUrl, int photoId, int w, int h) {
    if (apiUrl.contains('via.placeholder.com') || apiUrl.contains('placehold.it')) {
      final pid = ((photoId - 1) % 999) + 1;
      return 'https://picsum.photos/id/$pid/$w/$h';
    }
    return apiUrl;
  }

  String _shortTitle(String raw) {
    final parts = raw.split(' ');
    if (parts.length <= 3) return raw;
    return parts.take(3).join(' ');
  }

  /// (displayTitle, location, lat, lng, region)
  (String, String, double, double, String) _destinationForId(int id) {
    const spots = <(String, String, double, double, String)>[
      ('Lake Tekapo', 'New Zealand', -43.8833, 170.5167, 'Oceania'),
      ('Santorini Caldera', 'Greece', 36.3932, 25.4615, 'Europe'),
      ('Banff Town', 'Canada', 51.1784, -115.5708, 'Americas'),
      ('Kyoto Gardens', 'Japan', 35.0116, 135.7681, 'Asia'),
      ('Marrakech Medina', 'Morocco', 31.6295, -7.9811, 'Africa'),
      ('Patagonia Peaks', 'Argentina', -50.9423, -73.4068, 'Americas'),
      ('Reykjavik Lights', 'Iceland', 64.1466, -21.9426, 'Europe'),
      ('Ha Long Bay', 'Vietnam', 20.9101, 107.1839, 'Asia'),
      ('Zermatt Village', 'Switzerland', 46.0207, 7.7491, 'Europe'),
      ('Cape Town Coast', 'South Africa', -33.9249, 18.4241, 'Africa'),
      ('Big Sur Cliffs', 'USA', 36.2704, -121.8081, 'Americas'),
      ('Dolomites Trail', 'Italy', 46.4102, 11.8440, 'Europe'),
    ];
    return spots[id % spots.length];
  }
}

class PlacesException implements Exception {
  const PlacesException(this.code, this.message);
  final String code;
  final String message;

  @override
  String toString() => message;
}
