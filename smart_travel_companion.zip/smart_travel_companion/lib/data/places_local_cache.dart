import 'dart:convert';

import '../models/place.dart';
import 'cache_file.dart';

class PlacesLocalCache {
  Future<void> savePlaces(List<Place> places) async {
    final raw = jsonEncode(places.map((e) => e.toJson()).toList());
    await savePlacesFile(raw);
  }

  Future<List<Place>?> loadPlaces() async {
    try {
      final s = await loadPlacesFile();
      if (s == null || s.isEmpty) return null;
      final list = jsonDecode(s) as List<dynamic>;
      return list
          .map((e) => Place.fromJson(Map<String, dynamic>.from(e as Map)))
          .toList();
    } catch (_) {
      return null;
    }
  }
}
