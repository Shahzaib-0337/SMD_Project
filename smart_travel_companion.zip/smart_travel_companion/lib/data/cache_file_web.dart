Future<void> savePlacesFile(String json) async {}

Future<String?> loadPlacesFile() async => null;
