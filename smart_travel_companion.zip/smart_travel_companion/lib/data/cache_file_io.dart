import 'dart:io';

import 'package:path_provider/path_provider.dart';

const _fileName = 'places_cache.json';

Future<void> savePlacesFile(String json) async {
  final dir = await getApplicationDocumentsDirectory();
  final file = File('${dir.path}/$_fileName');
  await file.writeAsString(json);
}

Future<String?> loadPlacesFile() async {
  final dir = await getApplicationDocumentsDirectory();
  final file = File('${dir.path}/$_fileName');
  if (!await file.exists()) return null;
  return file.readAsString();
}
