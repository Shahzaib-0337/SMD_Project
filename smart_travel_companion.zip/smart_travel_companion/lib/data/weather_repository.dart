import 'dart:convert';

import 'package:http/http.dart' as http;

import '../models/weather_snapshot.dart';

class WeatherRepository {
  WeatherRepository({http.Client? httpClient}) : _http = httpClient ?? http.Client();
  final http.Client _http;

  /// Open-Meteo needs query parameters (latitude, longitude, current variables).
  /// A bare `https://api.open-meteo.com/v1/forecast` URL returns no forecast payload.
  /// Docs: https://api.open-meteo.com/v1/forecast
  Future<WeatherSnapshot> fetchCurrent({
    required double latitude,
    required double longitude,
  }) async {
    final uri = Uri.https('api.open-meteo.com', '/v1/forecast', {
      'latitude': latitude.toString(),
      'longitude': longitude.toString(),
      'current': 'temperature_2m,relative_humidity_2m,apparent_temperature,wind_speed_10m,weather_code',
      'wind_speed_unit': 'kmh',
    });
    try {
      final res = await _http.get(
        uri,
        headers: const {'Accept': 'application/json', 'User-Agent': 'SmartTravelCompanion/1.0'},
      );
      if (res.statusCode != 200 || res.body.isEmpty) {
        return _fallback(isLive: false, note: 'HTTP ${res.statusCode}');
      }
      final map = jsonDecode(res.body);
      if (map is! Map<String, dynamic>) {
        return _fallback(isLive: false, note: 'Unexpected JSON');
      }
      final cur = map['current'];
      if (cur is! Map<String, dynamic>) {
        return _fallback(isLive: false, note: 'Missing current (check lat/lon query params)');
      }
      final code = (cur['weather_code'] as num?)?.toInt() ?? 0;
      return WeatherSnapshot(
        temperatureC: _readDouble(cur, 'temperature_2m', 16),
        apparentC: _readDouble(cur, 'apparent_temperature', 16),
        humidityPct: _readInt(cur, 'relative_humidity_2m', 50),
        windKmh: _readDouble(cur, 'wind_speed_10m', 10),
        label: _labelForWmo(code),
        isLive: true,
      );
    } catch (_) {
      return _fallback(isLive: false, note: 'Network or parse error');
    }
  }

  double _readDouble(Map<String, dynamic> m, String key, double fallback) {
    final v = m[key];
    if (v is num) return v.toDouble();
    return fallback;
  }

  int _readInt(Map<String, dynamic> m, String key, int fallback) {
    final v = m[key];
    if (v is num) return v.round();
    return fallback;
  }

  WeatherSnapshot _fallback({required bool isLive, String? note}) {
    return WeatherSnapshot(
      temperatureC: 18,
      apparentC: 17,
      humidityPct: 55,
      windKmh: 12,
      label: note == null ? 'Clear sky' : 'Demo · $note',
      isLive: isLive,
    );
  }

  String _labelForWmo(int code) {
    if (code == 0) return 'Clear sky';
    if (code <= 3) return 'Partly cloudy';
    if (code <= 48) return 'Foggy';
    if (code <= 67) return 'Rainy';
    if (code <= 77) return 'Snowy';
    if (code <= 82) return 'Rain showers';
    if (code <= 86) return 'Snow showers';
    if (code <= 99) return 'Stormy';
    return 'Weather';
  }
}
