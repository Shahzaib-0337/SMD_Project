export 'cache_file_io.dart' if (dart.library.html) 'cache_file_web.dart';
